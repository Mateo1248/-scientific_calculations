# Mateusz Kościelniak
# indeks: 244973

include("../src/Interpol.jl")
using .Interpol, Test 

@testset "naturalna" begin
    @test naturalna(Float64[1,-2,4], Float64[3, 5, 7]) ≈ Float64[3, -1/3, 1/3] atol=0.00000000000001
end