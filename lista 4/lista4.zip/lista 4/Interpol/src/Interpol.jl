#Mateusz Kościelniak
#indeks: 244973

module Interpol
    export ilorazyRoznicowe, warNewton, naturalna, rysujNnfx

    include("ex1.jl")
    include("ex2.jl")
    include("ex3.jl")
    include("ex4.jl")
end